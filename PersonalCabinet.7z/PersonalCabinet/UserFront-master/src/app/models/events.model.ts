  export class Event {
  id?: any;
  nameEvent?: string;
  description?: string;
  place?: string;
  archived: boolean;
  date_time: string;
  url: string;
  urlPhoto: string;
  score: number;
  category_id: number;

}
