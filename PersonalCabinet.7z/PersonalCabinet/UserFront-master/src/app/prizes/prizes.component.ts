import { Component } from '@angular/core';

@Component({
  selector: 'app-prizes',
  standalone: true,
  imports: [],
  templateUrl: './prizes.component.html',
  styleUrl: './prizes.component.scss'
})
export class PrizesComponent {

}
