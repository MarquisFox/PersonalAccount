import { Component } from '@angular/core';

@Component({
  selector: 'app-events-page',
  standalone: true,
  imports: [],
  templateUrl: './events-page.component.html',
  styleUrl: './events-page.component.scss'
})
export class EventsPageComponent {

}
