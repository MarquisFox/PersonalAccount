import { Component } from '@angular/core';

@Component({
  selector: 'app-addachivment',
  standalone: true,
  imports: [],
  templateUrl: './addachivment.component.html',
  styleUrl: './addachivment.component.scss'
})
export class AddachivmentComponent {

}
